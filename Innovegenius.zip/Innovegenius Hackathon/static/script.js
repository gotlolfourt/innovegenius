// ═══════════════════════════════════════════════════════════
// STATE
// ═══════════════════════════════════════════════════════════
const S = {
  appId: null,
  userData: {},
  // FIX 1: currentStep replaces awaitingInput — no more null-guard blocking
  currentStep: 'idle',
  riskLevel: null, riskScore: null,
  accountNumber: null, ifsc: null,
  generatedOTP: null,
  timerStart: Date.now(),
  selectedAppId: null,
};

// ═══════════════════════════════════════════════════════════
// API
// ═══════════════════════════════════════════════════════════
// async function api(method, path, body) {
//   try {
//     const opts = { method, headers:{'Content-Type':'application/json'}, credentials:'include' };
//     if (body) opts.body = JSON.stringify(body);
//     const res = await fetch(path, opts);
//     const data = await res.json();
//     if (!res.ok) throw new Error(data.error || 'API error ' + res.status);
//     return data;
//   } catch(e) { showToast('❌ ' + e.message, 'error'); throw e; }
// }

async function api(method, path, body) {
  try {
    const opts = { method, headers:{'Content-Type':'application/json'}, credentials:'include' };
    if (body) opts.body = JSON.stringify(body);
    console.log(`[API ${method}] ${path}`, body || '');
    const res = await fetch(path, opts);
    const ct = res.headers.get('content-type') || '';
    const data = ct.includes('json') ? await res.json() : { error: await res.text() };
    if (!res.ok) throw new Error(data.error || 'API error ' + res.status);
    console.log(`[API Response] ${path}`, data);
    return data;
  } catch(e) {
    // transient DB lock? retry once after brief pause
    if (e.message && e.message.toLowerCase().includes('database busy')) {
      await delay(400);
      return api(method, path, body);
    }
    console.error(`[API Error] ${path}:`, e.message);
    showToast('❌ ' + e.message, 'error');
    throw e;
  }
}

async function apiForm(path, fd) {
  try {
    const res = await fetch(path, { method:'POST', body:fd, credentials:'include' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Upload error');
    return data;
  } catch(e) { showToast('❌ ' + e.message, 'error'); throw e; }
}

async function sha256(str) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
  return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
}

// ═══════════════════════════════════════════════════════════
// SCREENS
// ═══════════════════════════════════════════════════════════
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

setInterval(() => {
  const el = document.getElementById('sessionTimer');
  if (!el) return;
  const s = Math.floor((Date.now()-S.timerStart)/1000);
  el.textContent = String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');
}, 1000);

// ═══════════════════════════════════════════════════════════
// START
// ═══════════════════════════════════════════════════════════

// helper ensures we have an application/session id; creates one if missing
async function ensureAppId() {
  if (S.appId) {
    console.log('[ensureAppId] REUSING existing appId:', S.appId);
    return S.appId;
  }
  
  console.log('[ensureAppId] Creating NEW session (S.appId is currently:', S.appId + ')');
  try {
    const data = await api('POST', '/api/session/start');
    S.appId = data.application_id;
    console.log('[ensureAppId] ✓ Session created:', S.appId);
    // Update UI elements
    const sessionEl = document.getElementById('sessionId');
    if (sessionEl) sessionEl.textContent = 'Session: ' + S.appId;
    const appIdEl = document.getElementById('inf-appid');
    if (appIdEl) appIdEl.textContent = S.appId;
    logAI('Session created in DB ✓');
  } catch(e) {
    // Fallback to offline mode
    S.appId = 'NXB-OFFLINE-' + Math.random().toString(36).substr(2,6).toUpperCase();
    console.log('[ensureAppId] ✗ API failed, using offline mode:', S.appId);
    const sessionEl = document.getElementById('sessionId');
    if (sessionEl) sessionEl.textContent = 'Offline: ' + S.appId;
    const appIdEl = document.getElementById('inf-appid');
    if (appIdEl) appIdEl.textContent = S.appId;
    const statusEl = document.getElementById('apiStatus');
    if (statusEl) {
      statusEl.textContent = '● Offline';
      statusEl.style.color = 'var(--orange)';
    }
  }
  console.log('[ensureAppId] Returning appId:', S.appId);
  return S.appId;
}

async function startOnboarding() {
  console.log('>>> START ONBOARDING - current S.appId:', S.appId);
  
  // Check if already in onboarding (prevent double-click)
  if (S.currentStep !== 'idle' && S.currentStep !== 'busy') {
    console.warn('>>> Already in onboarding flow, ignoring restart request');
    return;
  }
  
  // wipe previous chat/state in case this is a restart
  S.userData = {};
  S.currentStep = 'idle';
  S.riskLevel = S.riskScore = null;
  S.accountNumber = S.ifsc = null;
  S.generatedOTP = null;
  S.timerStart = Date.now();
  document.getElementById('chatMessages').innerHTML = '';
  document.getElementById('quickActions').innerHTML = '';
  // reset info panel values EXCEPT appId (preserve session across restarts)
  ['inf-name','inf-dob','inf-email','inf-idtype','inf-risk'].forEach(id => {
    const el = document.getElementById(id);
    if(el) el.textContent = '—';
  });
  if (!S.appId) {
    const appIdEl = document.getElementById('inf-appid');
    if(appIdEl) appIdEl.textContent = '—';
  }
  document.getElementById('apiStatus').textContent = '● API Connected';
  document.getElementById('apiStatus').style.color = 'var(--green)';

  showScreen('onboarding');

  // ensure session exists before chat begins
  console.log('>>> Calling ensureAppId from startOnboarding');
  await ensureAppId();
  console.log('>>> ensureAppId returned, S.appId now:', S.appId);

  // allow typing immediately (user can answer before AI speaks)
  S.currentStep = 'name';
  enableInput('Enter your full name…');

  console.log('>>> startOnboarding complete, S.appId:', S.appId);
  setTimeout(initChat, 300);
}

// ═══════════════════════════════════════════════════════════
// CHAT INIT
// ═══════════════════════════════════════════════════════════
function initChat() {
  addAiMsg("👋 Welcome to <strong>NexaBank</strong>! I'm <strong>ARIA</strong> — your AI onboarding assistant. I'll securely guide you through account creation.");
  setTimeout(() => {
    addAiMsg("Let's start! What is your <strong>full name</strong> as it appears on your government-issued ID?");
    // note: input already enabled in startOnboarding
  }, 1500);
}

// ═══════════════════════════════════════════════════════════
// SEND MESSAGE
// FIX 3: removed !S.awaitingInput guard. Now uses currentStep.
// Text input only valid in text-collection steps.
// ═══════════════════════════════════════════════════════════
function sendMsg() {
  const inp = document.getElementById('chatInput');
  const text = inp.value.trim();
  if (!text) return;
  // Only allow text input during these steps
  const textSteps = ['name','dob','email','phone'];
  if (!textSteps.includes(S.currentStep)) return;

  inp.value = ''; autoResize(inp);
  addUserMsg(text);
  setQuickActions([]);
  disableInput();
  setTimeout(() => handleStep(text), 200);
}

// ═══════════════════════════════════════════════════════════
// HANDLE STEP
// FIX 4: single unified function — no double-definition override
// ═══════════════════════════════════════════════════════════
async function handleStep(text) {
  // ensure we have an application/session id before doing anything
  console.log('[handleStep] Ensuring appId, current value:', S.appId);
  await ensureAppId();
  console.log('[handleStep] After ensureAppId, value is:', S.appId);

  // store user message in backend chat history (no harmful even if server offline)
  try {
    await api('POST', '/api/chat/message', {
      application_id: S.appId, message: text, step: S.currentStep
    });
  } catch(_) {
    // non‑fatal, let flow continue
  }

  switch(S.currentStep) {

    case 'name':
      if (text.trim().split(' ').length < 2) {
        addAiMsg("⚠️ Please enter your <strong>full name</strong> — first and last name as on your ID.");
        S.currentStep = 'name'; enableInput('Your full name…'); return;
      }
      S.userData.name = text.trim();
      document.getElementById('inf-name').textContent = S.userData.name;
      logAI('Name: ' + S.userData.name);
      addAiMsg(`Nice to meet you, <strong>${S.userData.name}</strong>! 👋<br>What is your <strong>date of birth</strong>?<br><span style="color:var(--text2);font-size:.82rem;">Format: YYYY-MM-DD &nbsp;e.g. 1996-03-15</span>`);
      S.currentStep = 'dob'; enableInput('YYYY-MM-DD');
      break;

    case 'dob':
      if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) {
        addAiMsg("⚠️ Please use the format <strong>YYYY-MM-DD</strong> (e.g. 1996-03-15).");
        S.currentStep = 'dob'; enableInput('YYYY-MM-DD'); return;
      }
      const ageMs = Date.now() - new Date(text).getTime();
      const age = Math.floor(ageMs / (365.25*24*3600*1000));
      if (age < 18) {
        addAiMsg(`⛔ You must be <strong>18 or older</strong>. Calculated age: <strong>${age}</strong>.`);
        S.currentStep = 'dob'; enableInput('YYYY-MM-DD'); return;
      }
      S.userData.dob = text;
      document.getElementById('inf-dob').textContent = text;
      logAI('DOB validated — age ' + age);
      addAiMsg(`✅ Age verified (${age} years old).<br>What is your <strong>email address</strong>?`);
      S.currentStep = 'email'; enableInput('your@email.com');
      break;

    case 'email':
      if (!/^[\w.+-]+@[\w-]+\.[a-zA-Z]{2,}$/.test(text)) {
        addAiMsg("⚠️ Please enter a valid <strong>email address</strong>.");
        S.currentStep = 'email'; enableInput('your@email.com'); return;
      }
      S.userData.email = text;
      document.getElementById('inf-email').textContent = text;
      addAiMsg(`📧 Got it! And your <strong>mobile number</strong> with country code?<br><span style="color:var(--text2);font-size:.82rem;">e.g. +91-9876543210</span>`);
      S.currentStep = 'phone'; enableInput('+91-XXXXXXXXXX');
      break;

    case 'phone':
      S.userData.phone = text;
      S.currentStep = 'busy'; disableInput();
      const mEl = addAiMsg(`<div class="connecting-anim"><div class="spinner"></div> Saving identity to database…</div>`);
      try {
        await api('POST', '/api/identity/submit', {
          application_id: S.appId,
          name: S.userData.name, dob: S.userData.dob,
          email: S.userData.email, phone: text
        });
        markStep(1,'done'); markVerify('vchk-id','done');
        logAI('Identity saved to DB ✓');
        updateBubble(mEl, '✅ Identity details saved to database!', 'ok');
        await delay(600);
        addAiMsg("Now I need your <strong>ID document</strong>. Please upload your Aadhaar Card, PAN Card, or Passport.");
        S.currentStep = 'doc';
        setTimeout(showDocUpload, 400);
      } catch(e) {
        updateBubble(mEl, `⚠️ ${e.message}. Please re-enter your details.`);
        S.currentStep = 'name'; enableInput('Your full name…');
      }
      break;
  }
}

// ═══════════════════════════════════════════════════════════
// DOCUMENT UPLOAD
// FIX 5: simulate sends a real PNG canvas blob so backend doesn't get 400
// ═══════════════════════════════════════════════════════════
function showDocUpload() {
  markStep(2,'checking');
  const w = document.createElement('div');
  w.className = 'msg ai'; w.id = 'docWidget'; w.style.maxWidth = '100%';
  w.innerHTML = `
    <div class="msg-avatar">🤖</div>
    <div style="flex:1;">
      <select id="docTypeSelect" style="width:100%;background:var(--bg3);border:1px solid var(--border);color:var(--text);font-family:'Outfit',sans-serif;padding:9px 13px;border-radius:8px;margin-bottom:10px;outline:none;font-size:.85rem;">
        <option value="Aadhaar">Aadhaar Card</option>
        <option value="PAN">PAN Card</option>
        <option value="Passport">Passport</option>
      </select>
      <div class="upload-zone">
        <input type="file" accept="image/png,image/jpeg,image/jpg,.pdf" onchange="uploadRealDoc(this)">
        <div style="font-size:2rem;margin-bottom:8px;">📎</div>
        <div style="font-size:.85rem;color:var(--text2);">Click or drag to upload &nbsp;<span style="color:var(--gold)">Aadhaar / PAN / Passport</span></div>
        <div style="font-size:.72rem;color:var(--text2);margin-top:4px;">PNG, JPG or PDF · Max 16MB · Real OCR will run</div>
      </div>
      <div style="margin-top:10px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap;">
        <button class="quick-btn" onclick="simulateDoc('Aadhaar')">📄 Simulate Aadhaar</button>
        <button class="quick-btn" onclick="simulateDoc('PAN')">🪪 Simulate PAN</button>
        <button class="quick-btn" onclick="simulateDoc('Passport')">📘 Simulate Passport</button>
      </div>
    </div>`;
  document.getElementById('chatMessages').appendChild(w);
  scrollChat();
}

async function uploadRealDoc(input) {
  const file = input.files[0];
  if (!file) return;
  const docType = document.getElementById('docTypeSelect')?.value || 'Aadhaar';
  document.getElementById('docWidget')?.remove();
  addUserMsg(`📎 Uploading: ${file.name} (${docType})`);
  const fd = new FormData();
  fd.append('file', file);
  fd.append('doc_type', docType);
  fd.append('application_id', S.appId);
  await processDoc(docType, fd);
}

async function simulateDoc(type) {
  document.getElementById('docWidget')?.remove();
  addUserMsg(`📄 Simulating: ${type} Card`);

  // Build a real PNG blob so the server file upload doesn't fail
  const canvas = document.createElement('canvas');
  canvas.width = 400; canvas.height = 240;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#f5f5f0'; ctx.fillRect(0,0,400,240);
  ctx.fillStyle = '#1a1a2e'; ctx.fillRect(0,0,400,50);
  ctx.fillStyle = '#ffffff'; ctx.font = 'bold 18px Arial'; ctx.fillText('GOVERNMENT OF INDIA', 15, 32);
  ctx.fillStyle = '#1a1a2e'; ctx.font = '14px Arial';
  const lines = {
    Aadhaar: ['Aadhaar Card', 'Name: Demo Applicant', 'DOB: 01/01/1995', 'XXXX XXXX 1234'],
    PAN: ['PAN Card', 'Name: DEMO APPLICANT', 'DOB: 01/01/1995', 'ABCDE1234F'],
    Passport: ['Passport', 'Name: Demo Applicant', 'DOB: 01/01/1995', 'P1234567'],
  };
  (lines[type]||lines.Aadhaar).forEach((l,i) => { ctx.fillText(l, 20, 80 + i*32); });
  ctx.strokeStyle = '#cccccc'; ctx.strokeRect(2,2,396,236);

  const blob = await new Promise(r => canvas.toBlob(r, 'image/png'));
  const fd = new FormData();
  fd.append('file', blob, `${type}_simulation.png`);
  fd.append('doc_type', type);
  fd.append('application_id', S.appId);
  await processDoc(type, fd);
}

async function processDoc(docType, fd) {
  document.getElementById('inf-idtype').textContent = docType;
  const mEl = addAiMsg(`<div><div class="connecting-anim"><div class="spinner"></div> Running OCR on ${docType}…</div><div class="ai-loading-bar"><div class="ai-loading-fill"></div></div></div>`);
  logAI('OCR engine: ' + docType);
  await delay(800);
  updateBubble(mEl, `<div><div class="connecting-anim"><div class="spinner"></div> Cross-referencing government database…</div><div class="ai-loading-bar"><div class="ai-loading-fill"></div></div></div>`);
  await delay(800);
  updateBubble(mEl, `<div><div class="connecting-anim"><div class="spinner"></div> Tamper detection & authenticity check…</div><div class="ai-loading-bar"><div class="ai-loading-fill"></div></div></div>`);

  try {
    const res = await apiForm('/api/documents/upload', fd);
    const ocr = res.ocr || {};
    const flags = res.tamper_flags || [];
    const conf = ocr.confidence || 0;
    const confColor = conf >= 70 ? 'var(--green)' : conf >= 40 ? 'var(--orange)' : 'var(--red)';
    const ocrLine = (ocr.name || ocr.id_number) ? `<br>OCR → Name: ${ocr.name||'—'} | ID: ${ocr.id_number||'—'}` : '';
    const hashLine = `<br><span style="font-family:'DM Mono',monospace;font-size:.72rem;color:var(--text2);">SHA-256: ${(res.file_hash||'').substring(0,22)}…</span>`;
    const flagLine = flags.length ? `<br><span style="color:var(--orange);">⚠️ ${flags.join(', ')}</span>` : '';

    updateBubble(mEl,
      `✅ <strong>${docType} processed!</strong><br>
       ${res.file_size_kb}KB uploaded | OCR: <span style="color:${confColor}">${conf}%</span>${ocrLine}${flagLine}${hashLine}`,
      flags.length ? 'warn' : 'ok');

    markStep(2,'done'); markVerify('vchk-doc','done');
    logAI(`Doc OK: ${docType} | conf ${conf}% | hash stored`);
    await delay(800);
    addAiMsg("📸 Almost there! Please take a <strong>selfie</strong> for biometric face verification.");
    S.currentStep = 'selfie';
    setTimeout(showSelfieCapture, 400);
  } catch(e) {
    updateBubble(mEl, `⚠️ Failed: ${e.message}. Please try again.`);
    setTimeout(showDocUpload, 1000);
  }
}

// ═══════════════════════════════════════════════════════════
// SELFIE
// FIX 6: sends actual image file to /api/biometric/selfie with key 'selfie'
// ═══════════════════════════════════════════════════════════
function showSelfieCapture() {
  markStep(3,'checking');
  const w = document.createElement('div');
  w.className = 'msg ai'; w.id = 'selfieWidget'; w.style.maxWidth = '100%';
  w.innerHTML = `
    <div class="msg-avatar">🤖</div>
    <div style="flex:1;">
      <div class="selfie-zone">
        <input type="file" accept="image/*" capture="user" onchange="uploadSelfie(this)">
        <div style="font-size:3rem;">🤳</div>
        <div style="margin-top:8px;font-size:.85rem;color:var(--text2);">Click to take photo or upload selfie</div>
        <div style="font-size:.72rem;color:var(--text2);margin-top:4px;">Stored securely on server</div>
      </div>
      <div style="margin-top:10px;text-align:center;">
        <button class="quick-btn" onclick="simulateSelfie()">📸 Simulate Selfie</button>
      </div>
    </div>`;
  document.getElementById('chatMessages').appendChild(w);
  scrollChat();
}

async function uploadSelfie(input) {
  const file = input.files[0];
  if (!file) return;
  document.getElementById('selfieWidget')?.remove();
  addUserMsg('📸 Selfie taken');
  const fd = new FormData();
  fd.append('selfie', file);         // key must be 'selfie' — matches backend
  fd.append('application_id', S.appId);
  await processSelfie(fd);
}

async function simulateSelfie() {
  document.getElementById('selfieWidget')?.remove();
  addUserMsg('📸 Selfie captured (simulated)');

  // FIX 6 continued: generate real PNG blob — backend requires an actual file
  const canvas = document.createElement('canvas');
  canvas.width = 300; canvas.height = 300;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#1a2744'; ctx.fillRect(0,0,300,300);
  // Face
  ctx.fillStyle = '#F5CBA7'; ctx.beginPath(); ctx.arc(150,130,70,0,Math.PI*2); ctx.fill();
  // Eyes
  ctx.fillStyle = '#2C3E50'; ctx.beginPath(); ctx.arc(125,115,10,0,Math.PI*2); ctx.fill();
  ctx.beginPath(); ctx.arc(175,115,10,0,Math.PI*2); ctx.fill();
  // Smile
  ctx.strokeStyle = '#C9A84C'; ctx.lineWidth=4; ctx.beginPath(); ctx.arc(150,135,30,0,Math.PI); ctx.stroke();
  // Hair
  ctx.fillStyle = '#2C3E50'; ctx.beginPath(); ctx.arc(150,72,48,Math.PI,0); ctx.fill();
  // Shirt
  ctx.fillStyle = '#C9A84C'; ctx.beginPath(); ctx.moveTo(80,300); ctx.lineTo(80,230); ctx.lineTo(150,210); ctx.lineTo(220,230); ctx.lineTo(220,300); ctx.fill();

  const blob = await new Promise(r => canvas.toBlob(r, 'image/png'));
  const fd = new FormData();
  fd.append('selfie', blob, 'selfie.png');
  fd.append('application_id', S.appId);
  await processSelfie(fd);
}

async function processSelfie(fd) {
  const mEl = addAiMsg(`<div class="connecting-anim"><div class="spinner"></div> Uploading selfie securely…</div>`);
  logAI('Biometric: upload started');
  await delay(700);
  updateBubble(mEl, `<div class="connecting-anim"><div class="spinner"></div> Running facial recognition…</div>`);
  await delay(1000);
  updateBubble(mEl, `<div class="connecting-anim"><div class="spinner"></div> Liveness detection & anti-spoofing…</div>`);

  try {
    const res = await apiForm('/api/biometric/selfie', fd);
    const score = res.face_score;
    const sc = score >= 90 ? 'var(--green)' : score >= 75 ? 'var(--orange)' : 'var(--red)';
    updateBubble(mEl,
      `✅ <strong>Selfie stored!</strong><br>
       Face match: <span style="color:${sc}"><strong>${score}%</strong></span> (${res.face_status})<br>
       Liveness: <span style="color:var(--green)">✓ Detected</span><br>
       <span style="font-size:.75rem;color:var(--text2);">Stored as: ${res.selfie_stored}</span>`, 'ok');

    markStep(3,'done'); markVerify('vchk-bio','done');
    logAI(`Face match: ${score}%`);
    await delay(800);
    await doOTP();
  } catch(e) {
    updateBubble(mEl, `⚠️ Selfie upload failed: ${e.message}`);
    setTimeout(showSelfieCapture, 1000);
  }
}

// ═══════════════════════════════════════════════════════════
// OTP
// FIX 7: uses /api/otp/store (not /api/otp/send) + SHA-256 hash
// ═══════════════════════════════════════════════════════════
async function doOTP() {
  markStep(4,'checking');
  S.currentStep = 'busy';
  
  // Ensure we have an app ID before generating OTP
  await ensureAppId();
  // At this point S.appId is guaranteed to be set (either real or offline)
  
  console.log('DEBUG doOTP: S.appId =', S.appId);

  // Generate random 6-digit OTP client-side
  S.generatedOTP = String(Math.floor(100000 + Math.random() * 900000));
  const hash = await sha256(S.generatedOTP);
  
  console.log('DEBUG doOTP: Generated OTP hash, storing with app_id:', S.appId);

  // Store hash in backend (non-fatal if it fails)
  try {
    const storeRes = await api('POST', '/api/otp/store', { application_id: S.appId, otp_hash: hash });
    console.log('DEBUG doOTP: OTP store response:', storeRes);
    logAI('OTP hash stored in DB ✓');
  } catch(e) {
    console.error('DEBUG doOTP: OTP store failed:', e);
    logAI('⚠️ OTP store note: ' + e.message);
  }

  // Show OTP visually (simulating SMS delivery)
  const otpDiv = document.createElement('div');
  otpDiv.className = 'msg ai'; otpDiv.style.maxWidth = '100%';
  otpDiv.innerHTML = `
    <div class="msg-avatar">🤖</div>
    <div class="msg-bubble gold">
      📱 OTP sent to <strong>${S.userData.email}</strong>
      <div style="background:var(--bg);border:1px solid var(--border);border-radius:10px;padding:16px;text-align:center;margin-top:10px;">
        <div style="font-size:.72rem;color:var(--text2);margin-bottom:8px;">YOUR OTP (shown for demo)</div>
        <div style="font-family:'DM Mono',monospace;font-size:2.2rem;letter-spacing:10px;color:var(--gold);font-weight:700;">${S.generatedOTP}</div>
        <div style="font-size:.7rem;color:var(--text2);margin-top:8px;">Valid for 5 minutes</div>
      </div>
    </div>`;
  document.getElementById('chatMessages').appendChild(otpDiv);
  scrollChat();

  await delay(500);
  addAiMsg("Please enter the 6-digit OTP shown above to verify your identity.");
  S.currentStep = 'otp';
  setTimeout(showOTPBoxes, 400);
}

function showOTPBoxes() {
  document.getElementById('otpWidget')?.remove();
  const w = document.createElement('div');
  w.className = 'msg ai'; w.id = 'otpWidget'; w.style.maxWidth = '100%';
  w.innerHTML = `
    <div class="msg-avatar">🤖</div>
    <div style="flex:1;">
      <div style="font-size:.85rem;margin-bottom:10px;color:var(--text2);">Enter your 6-digit OTP:</div>
      <div class="otp-boxes">
        ${[1,2,3,4,5,6].map(i=>`<input class="otp-box" id="otp${i}" type="number" inputmode="numeric"
          min="0" max="9" oninput="otpNext(this,${i})" onkeydown="otpBack(event,${i})">`).join('')}
      </div>
      <div style="text-align:center;margin-top:14px;">
        <button class="quick-btn" onclick="verifyOTP()" style="padding:10px 30px;">Verify OTP ✓</button>
      </div>
    </div>`;
  document.getElementById('chatMessages').appendChild(w);
  scrollChat();
  setTimeout(() => {
    const el = document.getElementById('otp1');
    if (el) el.focus();
  }, 200);
}

function otpNext(el, i) {
  // Only allow single digit input
  el.value = el.value.toString().slice(-1);
  // Auto-advance to next field
  if (el.value && i < 6) {
    document.getElementById('otp'+(i+1))?.focus();
  }
  // Auto-verify when last digit entered
  if (i === 6 && el.value) {
    setTimeout(verifyOTP, 300);
  }
}

function otpBack(e, i) {
  if (e.key === 'Backspace' && !e.target.value && i > 1) {
    document.getElementById('otp'+(i-1))?.focus();
  }
}

async function verifyOTP() {
  // Get all 6 OTP digits
  const otpInputs = [1,2,3,4,5,6].map(i=>document.getElementById('otp'+i));
  const digits = otpInputs.map(el => el?.value || '').join('');
  
  // Validate: must be exactly 6 numeric digits
  if (digits.length !== 6 || !/^\d{6}$/.test(digits)) {
    showToast('Please enter all 6 digits', 'error');
    if (otpInputs[0]) otpInputs[0].focus();
    return;
  }
  
  // Ensure we have an app ID before verifying
  await ensureAppId();
  
  // Verify S.appId is actually set
  if (!S.appId) {
    showToast('Session error: No application ID. Please restart.', 'error');
    await delay(1500);
    startOnboarding();
    return;
  }
  
  // Remove OTP widget and disable further input
  document.getElementById('otpWidget')?.remove();
  addUserMsg('OTP entered: ••••••');
  S.currentStep = 'busy';
  disableInput();

  const mEl = addAiMsg(`<div class="connecting-anim"><div class="spinner"></div> Verifying OTP…</div>`);

  try {
    // Hash the OTP and verify
    const hash = await sha256(digits);
    if (!hash) {
      throw new Error('Failed to compute OTP hash');
    }
    
    // Log for debugging
    console.log('OTP Verify Request:', { app_id: S.appId, hash: hash?.substring(0,16) + '...' });
    
    const res = await api('POST', '/api/otp/verify', { 
      application_id: S.appId, 
      otp_hash: hash 
    });
    
    if (res.verified || res.success) {
      updateBubble(mEl, '✅ <strong>OTP verified!</strong> Identity confirmed.', 'ok');
      markStep(4,'done');
      markVerify('vchk-otp','done');
      logAI('OTP verified ✓');
      await delay(800);
      await runRiskEval();
    } else {
      throw new Error('OTP verification failed');
    }
  } catch(e) {
    console.error('OTP Verify Error:', e);
    updateBubble(mEl, `❌ ${e.message || 'Incorrect OTP. Please check and try again.'}`);
    S.currentStep = 'otp';
    await delay(800);
    setTimeout(showOTPBoxes, 100);
  }
}

// ═══════════════════════════════════════════════════════════
// RISK EVALUATION
// FIX 8: /api/risk/evaluate already returns account_number + ifsc
// No separate /api/account/activate needed
// ═══════════════════════════════════════════════════════════
async function runRiskEval() {
  markStep(5,'checking'); markVerify('vchk-risk','checking');
  const checks = [
    'Analyzing document integrity…',
    'AML watchlist screening…',
    'Cross-referencing CIBIL data…',
    'Computing biometric confidence…',
    'Generating composite risk score…',
  ];
  const mEl = addAiMsg(`<div>
    <div class="connecting-anim"><div class="spinner"></div>${checks[0]}</div>
    <div class="ai-loading-bar"><div class="ai-loading-fill"></div></div>
    <div style="color:var(--text2);font-size:.75rem;margin-top:6px;">0/${checks.length} checks</div>
  </div>`);
  logAI('Risk engine: 5 factors');

  for (let i=1;i<checks.length;i++) {
    await delay(800);
    updateBubble(mEl, `<div>
      <div class="connecting-anim"><div class="spinner"></div>${checks[i]}</div>
      <div class="ai-loading-bar"><div class="ai-loading-fill"></div></div>
      <div style="color:var(--text2);font-size:.75rem;margin-top:6px;">${i}/${checks.length} checks</div>
    </div>`);
  }
  await delay(900);

  try {
    const res = await api('POST', '/api/risk/evaluate', { application_id: S.appId });
    S.riskLevel = res.risk_level;
    S.riskScore = res.risk_score;
    S.accountNumber = res.account_number;
    S.ifsc = res.ifsc;

    const C = {Low:'var(--green)',Medium:'var(--orange)',High:'var(--red)'};
    const E = {Low:'🟢',Medium:'🟠',High:'🔴'};
    const CL= {Low:'ok',Medium:'warn',High:'danger'};
    const c = C[res.risk_level];

    const sigRows = (res.signals||[]).map(s=>`
      <div style="display:flex;gap:10px;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.04);font-size:.78rem;">
        <span style="${s.weight<0?'color:var(--red)':'color:var(--text2)'};font-family:'DM Mono',monospace;min-width:36px;">${s.weight>0?'+'+s.weight:s.weight||'0'}</span>
        <span style="color:var(--text2);min-width:110px;">${s.factor}</span>
        <span>${s.note}</span>
      </div>`).join('');

    updateBubble(mEl, `
      <div style="color:${c};font-weight:600;font-size:.95rem;margin-bottom:8px;">${E[res.risk_level]} Risk: <strong>${res.risk_level}</strong></div>
      <div style="font-size:.83rem;color:var(--text2);margin-bottom:10px;">${res.risk_reason}</div>
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px;">
        <div style="flex:1;height:7px;background:rgba(255,255,255,.1);border-radius:4px;overflow:hidden;">
          <div style="height:100%;width:${res.risk_score}%;background:${c};border-radius:4px;"></div>
        </div>
        <span style="font-family:'DM Mono',monospace;font-size:.8rem;color:${c};">${res.risk_score}/100</span>
      </div>
      <div style="font-size:.75rem;border:1px solid rgba(255,255,255,.06);border-radius:8px;overflow:hidden;">
        <div style="padding:8px 12px;background:rgba(255,255,255,.02);font-size:.7rem;text-transform:uppercase;letter-spacing:1px;color:var(--gold);">Signal Breakdown</div>
        <div style="padding:8px 12px;">${sigRows}</div>
      </div>`, CL[res.risk_level]);

    markVerify('vchk-risk','done'); markStep(5,'done');
    const rEl = document.getElementById('inf-risk');
    rEl.textContent = res.risk_level;
    rEl.className = 'risk-badge '+(res.risk_level==='Low'?'low':res.risk_level==='Medium'?'med':'high');
    logAI(`Risk: ${res.risk_level} (${res.risk_score}/100)`);

    await delay(1400);
    if (res.risk_level === 'High') {
      addAiMsg(`⚠️ Application <strong style="color:var(--orange)">escalated for manual review</strong>.<br>Reference: <strong class="mono">${S.appId}</strong><br>Expected: 2-3 business days.`);
    } else {
      addAiMsg(`🚀 All checks passed! Your <strong>NexaBank account</strong> is now active.`, 0, 'gold');
    }
    await delay(1800);
    showSuccessScreen();
  } catch(e) {
    updateBubble(mEl, `⚠️ Risk evaluation failed: ${e.message}`);
  }
}

function showSuccessScreen() {
  document.getElementById('sc-appid').textContent = S.appId;
  document.getElementById('sc-name').textContent  = S.userData.name || '—';
  document.getElementById('sc-acno').textContent  = S.accountNumber || '—';
  document.getElementById('sc-ifsc').textContent  = S.ifsc || 'NXBA0001234';
  document.getElementById('sc-date').textContent  = new Date().toLocaleDateString('en-IN',{day:'numeric',month:'long',year:'numeric'});
  const rEl = document.getElementById('sc-risk');
  rEl.textContent = S.riskLevel||'Low';
  rEl.className = 'risk-badge '+(S.riskLevel==='High'?'high':S.riskLevel==='Medium'?'med':'low');
  showScreen('success-screen');
  launchConfetti();
}

// ═══════════════════════════════════════════════════════════
// CHAT HELPERS
// ═══════════════════════════════════════════════════════════
// function addAiMsg(html, delay2=0, cls='') {
//   const chat = document.getElementById('chatMessages');
//   const msgDiv = document.createElement('div');
//   msgDiv.className = 'msg ai';
//   const typing = document.createElement('div');
//   typing.className = 'msg ai';
//   typing.innerHTML = `<div class="msg-avatar">🤖</div><div class="msg-bubble"><div class="typing-indicator"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div></div>`;
//   const insert = () => {
//     chat.appendChild(typing); scrollChat();
//     setTimeout(() => {
//       msgDiv.innerHTML = `<div class="msg-avatar">🤖</div><div class="msg-bubble ${cls}">${html}</div>`;
//       typing.replaceWith(msgDiv); scrollChat();
//     }, 650);
//   };
//   if (delay2) setTimeout(insert, delay2); else insert();
//   return msgDiv;
// }

function addAiMsg(html, delay2=0, cls='') {
  const chat = document.getElementById('chatMessages');
  const msgDiv = document.createElement('div');
  msgDiv.className = 'msg ai';
  // Bubble is on msgDiv immediately so updateBubble() always finds it
  msgDiv.innerHTML = `<div class="msg-avatar">🤖</div><div class="msg-bubble ${cls}"><div class="typing-indicator"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div></div>`;
  
  let autoTimeout = null;
  const insert = () => {
    chat.appendChild(msgDiv); scrollChat();
    autoTimeout = setTimeout(() => {
      const b = msgDiv.querySelector('.msg-bubble');
      if (b) { b.className = `msg-bubble ${cls}`; b.innerHTML = html; }
      scrollChat();
    }, 650);
  };
  // expose a cancellation helper so updateBubble can cancel the pending update
  msgDiv._cancelAuto = () => { if (autoTimeout) { clearTimeout(autoTimeout); autoTimeout = null; } };

  if (delay2) setTimeout(insert, delay2); else insert();
  return msgDiv;
}

function addUserMsg(text) {
  const chat = document.getElementById('chatMessages');
  const d = document.createElement('div');
  d.className = 'msg user';
  d.innerHTML = `<div class="msg-avatar" style="background:var(--bg3);border:1px solid var(--border);">👤</div><div class="msg-bubble">${text}</div>`;
  chat.appendChild(d); scrollChat();
}

function updateBubble(el, html, cls='') {
  // cancel the auto‑update from addAiMsg (prevents spinner/content flip‑flop)
  if (el && typeof el._cancelAuto === 'function') el._cancelAuto();
  const b = el.querySelector('.msg-bubble');
  if (b) { b.innerHTML = html; if(cls) b.className = 'msg-bubble '+cls; }
}

function scrollChat() {
  const el = document.getElementById('chatMessages');
  if (el) setTimeout(() => el.scrollTop = el.scrollHeight, 100);
}

function enableInput(ph='Type your response…') {
  document.getElementById('chatInput').disabled = false;
  document.getElementById('chatInput').placeholder = ph;
  document.getElementById('sendBtn').disabled = false;
  document.getElementById('chatInput').focus();
}

function disableInput() {
  document.getElementById('chatInput').disabled = true;
  document.getElementById('chatInput').placeholder = 'Please wait…';
  document.getElementById('sendBtn').disabled = true;
}

function setQuickActions(actions) {
  const el = document.getElementById('quickActions');
  el.innerHTML = '';
  (actions||[]).forEach(a => {
    const btn = document.createElement('button');
    btn.className = 'quick-btn'; btn.textContent = a.label;
    btn.onclick = () => { document.getElementById('chatInput').value = a.val; sendMsg(); };
    el.appendChild(btn);
  });
}

function handleKey(e) { if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMsg();} }
function autoResize(el) { el.style.height='auto'; el.style.height=Math.min(el.scrollHeight,120)+'px'; }

// ═══════════════════════════════════════════════════════════
// STEP / VERIFY HELPERS
// ═══════════════════════════════════════════════════════════
function markStep(num, state) {
  const el = document.getElementById('step-'+num);
  if (!el) return;
  el.className = 'step-item '+(state==='done'?'done':'active');
  const c = el.querySelector('.step-circle');
  if (state==='done') {
    c.textContent = '✓';
    const line = document.getElementById('line-'+(num-1));
    if (line) line.classList.add('done');
    const next = document.getElementById('step-'+(num+1));
    if (next && !next.classList.contains('done')) next.classList.add('active');
  }
}

function markVerify(id, status) {
  const el = document.getElementById(id);
  if (!el) return;
  const icons = {done:'✓',fail:'✗',checking:'⟳'};
  if (icons[status]) el.textContent = icons[status];
  el.className = 'verify-icon '+status;
}

function logAI(msg) {
  const log = document.getElementById('aiLog');
  if (!log) return;
  const t = new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'});
  const item = document.createElement('div');
  item.className = 'timeline-item';
  item.innerHTML = `<span class="timeline-time">${t}</span><span>${msg}</span>`;
  log.appendChild(item);
  log.scrollTop = log.scrollHeight;
}

// ═══════════════════════════════════════════════════════════
// ADMIN MODAL (from admin.html — for embedded use)
// ═══════════════════════════════════════════════════════════
async function openReviewModal(appId) {
  S.selectedAppId = appId;
  try {
    const res = await api('GET', `/api/admin/application/${appId}`);
    const app = res.application;
    const docs = res.documents || [];
    const logs = (res.audit_log||[]).slice(0,6);
    const rCls = app.risk_level==='Low'?'low':app.risk_level==='Medium'?'med':'high';

    document.getElementById('modalContent').innerHTML = `
      <div class="info-row"><span class="info-key">Applicant</span><span class="info-val">${app.name||'—'}</span></div>
      <div class="info-row"><span class="info-key">App ID</span><span class="mono" style="font-size:.78rem;">${app.id}</span></div>
      <div class="info-row"><span class="info-key">DOB</span><span class="info-val">${app.dob||'—'}</span></div>
      <div class="info-row"><span class="info-key">Email</span><span class="info-val">${app.email||'—'}</span></div>
      <div class="info-row"><span class="info-key">Face Score</span><span class="info-val" style="color:${(app.face_score||0)>=75?'var(--green)':'var(--orange)'};">${app.face_score||0}% — ${app.face_status||'—'}</span></div>
      <div class="info-row"><span class="info-key">OTP Verified</span><span class="info-val" style="color:${app.otp_verified?'var(--green)':'var(--red)'};">${app.otp_verified?'✓ Yes':'✗ No'}</span></div>
      <div class="info-row"><span class="info-key">Risk</span>${app.risk_level?`<span class="risk-badge ${rCls}">${app.risk_level} (${app.risk_score}/100)</span>`:'—'}</div>
      <div class="info-row"><span class="info-key">Status</span><strong>${app.status||'—'}</strong></div>
      ${app.account_number?`<div class="info-row"><span class="info-key">Account</span><span class="mono" style="color:var(--gold);">${app.account_number}</span></div>`:''}
      <div class="divider"></div>
      <div class="ai-reasoning-box"><div class="ai-label">🤖 AI Risk Reasoning</div>${app.risk_reason||'Not evaluated'}</div>
      ${docs.length?`<div class="ai-reasoning-box"><div class="ai-label">📄 Documents (${docs.length})</div>${docs.map(d=>`
        <div style="display:flex;gap:10px;padding:5px 0;font-size:.8rem;border-bottom:1px solid rgba(255,255,255,.04);">
          <span style="color:var(--gold);">${d.doc_type}</span>
          <span style="color:var(--text2);">OCR: ${d.confidence||0}%</span>
          <span style="color:${d.verified?'var(--green)':'var(--red)'};">${d.verified?'✓ Verified':'✗ Unverified'}</span>
        </div>`).join('')}</div>`:''}
      <div class="ai-reasoning-box"><div class="ai-label">🕑 Audit Trail</div>${logs.map(l=>`
        <div style="font-size:.78rem;padding:4px 0;border-bottom:1px solid rgba(255,255,255,.04);color:var(--text2);">
          <span style="color:var(--gold);">${l.action}</span> — ${(l.detail||'').substring(0,60)}
          <span style="float:right;font-size:.7rem;">${(l.timestamp||'').substring(0,16)}</span>
        </div>`).join('')}</div>
      <textarea id="adminNotes" placeholder="Decision notes…" style="width:100%;background:var(--bg3);border:1px solid var(--border);color:var(--text);border-radius:8px;padding:10px;font-family:'Outfit',sans-serif;font-size:.85rem;outline:none;resize:vertical;min-height:60px;margin-top:12px;"></textarea>`;

    document.getElementById('reviewModal').classList.add('open');
  } catch(e) { showToast('Failed to load: ' + e.message, 'error'); }
}

async function submitDecision(decision) {
  const notes = document.getElementById('adminNotes')?.value || '';
  try {
    await api('POST', '/api/admin/decision', { application_id: S.selectedAppId, decision, notes });
    closeModal();
    showToast(`✅ ${decision} recorded`, 'success');
  } catch(e) {}
}

function closeModal() { document.getElementById('reviewModal').classList.remove('open'); }

// ═══════════════════════════════════════════════════════════
// UTILS
// ═══════════════════════════════════════════════════════════
function delay(ms) { return new Promise(r=>setTimeout(r,ms)); }

function showToast(msg, type='success') {
  const t = document.createElement('div');
  t.className = 'api-toast '+type; t.innerHTML = msg;
  document.body.appendChild(t); setTimeout(()=>t.remove(), 3500);
}

function launchConfetti() {
  const colors = ['#C9A84C','#E8C97A','#10B981','#3B82F6','#F59E0B','#EF4444'];
  for(let i=0;i<80;i++) setTimeout(()=>{
    const el=document.createElement('div'); el.className='confetti-piece';
    el.style.cssText=`left:${Math.random()*100}vw;top:-20px;background:${colors[Math.floor(Math.random()*colors.length)]};animation-duration:${2+Math.random()*2}s;animation-delay:${Math.random()*.5}s;width:${6+Math.random()*8}px;height:${6+Math.random()*8}px;border-radius:${Math.random()>.5?'50%':'2px'};`;
    document.body.appendChild(el); setTimeout(()=>el.remove(),4500);
  },i*40);
}